<?php
require_once __DIR__ . '/waf.php';

// Protect the admin page
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    die("Access denied");
}

// Load current WAF mode
require_once __DIR__ . '/config.php';

// Handle WAF toggle form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['waf_mode'])) {
    $newMode = $_POST['waf_mode'];
    $configPath = __DIR__ . '/config.php';

    file_put_contents($configPath, "<?php\n\$WAF_MODE = '$newMode';");

    $WAF_MODE = $newMode;
    $statusMessage = "WAF mode updated to $newMode";
}

// ---- WAF logs: read latest entries ----
$wafLogFile = __DIR__ . '/waf_logs/waf.log';
$wafLogs = [];

if (file_exists($wafLogFile)) {
    $lines = file($wafLogFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // show latest 50 entries (newest first)
    $lines = array_slice(array_reverse($lines), 0, 50);

    foreach ($lines as $line) {
        $entry = json_decode($line, true);
        if (is_array($entry)) {
            $wafLogs[] = $entry;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="icon" href="icon.ico" type="image/png">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
    }

    .sidebar {
      height: 100%;
      width: 250px;
      background-color: #232f3e;
      color: white;
      padding-top: 20px;
      position: fixed;
      top: 0;
      left: 0;
    }

    .sidebar a {
      display: block;
      color: white;
      padding: 15px;
      text-decoration: none;
      font-size: 18px;
    }

    .sidebar a:hover {
      background-color: #37475a;
    }

    .content {
      margin-left: 260px;
      padding: 20px;
    }

    .navbar {
      background-color: #131921;
      color: white;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .navbar h1 {
      margin: 0;
    }

    .navbar img {
      width: 100px;
      height: auto;
    }

    .admin-info {
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
    }

    .admin-info h2 {
      margin-top: 0;
    }

    .admin-info .welcome-text {
      font-size: 28px;
      font-weight: bold;
      color: #232f3e;
      text-align: center;
      margin-bottom: 20px;
    }

    .button {
      background-color: #f0c14b;
      border: none;
      color: #333;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 20px;
    }

    .button:hover {
      background-color: #d8ad40;
    }

    .p {
        color: white;
    }
  </style>
</head>
<body>

  <div class="sidebar">
    <h2 style="text-align:center; color:white;">Admin Panel</h2>
    <a href="#">Dashboard</a>
    <a href="users.php">User Management</a>
    <a href="#">Orders</a>
    <a href="#">Reports</a>
    <a href="#">Settings</a>
    <a href="logout.php">Logout</a>
  </div>

  <div class="content">

    <div class="navbar">
      <img src="amazinlogo.svg" alt="Amazin Logo">
      <h1>Amazin Admin Dashboard</h1>
      <a href="index.php" class="p">Home</a>
    </div>

    <div class="admin-info">
      <div class="welcome-text">Welcome to the Admin Panel</div>
      <p style="text-align:center;">Here you can manage users, view reports, and configure the system settings.</p>
      <div style="text-align:center;">
        <a href="users.php"><button class="button">Manage Users</button></a>
        <button class="button">View Reports</button>
      </div>
    </div>

    <!-- WAF Toggle Section -->
    <div class="admin-info">
      <h2>Web Application Firewall</h2>

      <p>Current Mode: <strong><?php echo htmlspecialchars($WAF_MODE); ?></strong></p>

      <?php
      if (!empty($statusMessage)) {
          echo "<p style='color:green; font-weight:bold;'>$statusMessage</p>";
      }
      ?>

      <form method="POST" style="text-align:center;">
          <label for="waf_mode"><strong>Set WAF Mode:</strong></label><br><br>
          <select name="waf_mode" id="waf_mode" style="padding:8px; font-size:16px;">
              <option value="OFF" <?php echo $WAF_MODE === 'OFF' ? 'selected' : ''; ?>>OFF</option>
              <option value="DETECT" <?php echo $WAF_MODE === 'DETECT' ? 'selected' : ''; ?>>DETECT</option>
              <option value="BLOCK" <?php echo $WAF_MODE === 'BLOCK' ? 'selected' : ''; ?>>BLOCK</option>
          </select>
          <br><br>
          <button class="button" type="submit">Update WAF Mode</button>
      </form>
    </div>

    <!-- WAF Logs Section -->
    <div class="admin-info">
      <h2>WAF Logs (latest events)</h2>

      <?php if (empty($wafLogs)): ?>
          <p>No WAF events logged yet.</p>
      <?php else: ?>
          <div style="max-height:300px; overflow-y:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:14px;">
              <thead>
                <tr>
                  <th style="border-bottom:1px solid #ddd; padding:6px; text-align:left;">Time</th>
                  <th style="border-bottom:1px solid #ddd; padding:6px; text-align:left;">Rule</th>
                  <th style="border-bottom:1px solid #ddd; padding:6px; text-align:left;">Message</th>
                  <th style="border-bottom:1px solid #ddd; padding:6px; text-align:left;">URI</th>
                  <th style="border-bottom:1px solid #ddd; padding:6px; text-align:left;">IP</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($wafLogs as $log): ?>
                <tr>
                  <td style="border-bottom:1px solid #eee; padding:6px;"><?php echo htmlspecialchars($log['time'] ?? ''); ?></td>
                  <td style="border-bottom:1px solid #eee; padding:6px;"><?php echo htmlspecialchars((string)($log['rule_id'] ?? '')); ?></td>
                  <td style="border-bottom:1px solid #eee; padding:6px;"><?php echo htmlspecialchars($log['message'] ?? ''); ?></td>
                  <td style="border-bottom:1px solid #eee; padding:6px;"><?php echo htmlspecialchars($log['uri'] ?? ''); ?></td>
                  <td style="border-bottom:1px solid #eee; padding:6px;"><?php echo htmlspecialchars($log['ip'] ?? ''); ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
      <?php endif; ?>
    </div>

  </div>

</body>
</html>
