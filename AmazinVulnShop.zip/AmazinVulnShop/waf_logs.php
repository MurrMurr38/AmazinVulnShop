<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    die("Access denied");
}

$logFile = __DIR__ . '/waf_logs/waf.log';

$lines = file_exists($logFile) ? file($logFile, FILE_IGNORE_NEW_LINES) : [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>WAF Logs</title>
<style>
    body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
    h1 { color: #232f3e; }
    table { width: 100%; border-collapse: collapse; background: white; }
    th, td { border: 1px solid #ddd; padding: 8px; }
    th { background: #232f3e; color: white; }
    tr:nth-child(even) { background: #f9f9f9; }
    .back-btn {
        padding: 10px 15px;
        background: #f0c14b;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
</style>
</head>
<body>

<h1>WAF Event Log</h1>

<a href="admin.php"><button class="back-btn">← Back to Admin</button></a>
<br><br>

<?php if (empty($lines)): ?>
    <p>No WAF logs found.</p>
<?php else: ?>
<table>
    <tr>
        <th>Time</th>
        <th>Rule ID</th>
        <th>Message</th>
        <th>URI</th>
        <th>IP</th>
    </tr>

    <?php foreach ($lines as $line): 
        $entry = json_decode($line, true);
        if (!$entry) continue;
    ?>
    <tr>
        <td><?= htmlspecialchars($entry['time']) ?></td>
        <td><?= htmlspecialchars($entry['rule_id']) ?></td>
        <td><?= htmlspecialchars($entry['message']) ?></td>
        <td><?= htmlspecialchars($entry['uri']) ?></td>
        <td><?= htmlspecialchars($entry['ip']) ?></td>
    </tr>
    <?php endforeach; ?>

</table>
<?php endif; ?>

</body>
</html>
