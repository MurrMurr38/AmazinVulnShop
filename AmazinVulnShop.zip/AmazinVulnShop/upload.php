<?php
require_once __DIR__ . '/waf.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $name = $_FILES['file']['name'];
    $tmp  = $_FILES['file']['tmp_name'];

    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png'];

    // When WAF is ON (DETECT or BLOCK), enforce allowed extensions
    if (defined('WAF_MODE') && WAF_MODE !== 'OFF') {
        if (!in_array($ext, $allowed, true)) {
            echo "File not supported. Only JPG, JPEG and PNG files are allowed.";
        } else {
            if (move_uploaded_file($tmp, "uploads/$name")) {
                echo "Uploaded $name";
            } else {
                echo "An error occurred while uploading the file.";
            }
        }
    } else {
        // WAF OFF -> fully vulnerable behavior, allow any file type
        if (move_uploaded_file($tmp, "uploads/$name")) {
            echo "Uploaded $name";
        } else {
            echo "An error occurred while uploading the file.";
        }
    }
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="file">
    <button type="submit">Upload</button>
</form>
