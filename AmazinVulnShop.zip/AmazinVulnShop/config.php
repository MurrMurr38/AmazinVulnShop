<?php
$WAF_MODE = 'BLOCK';