<?php
/*
|--------------------------------------------------------------------------
| Load WAF Mode From config.php
|--------------------------------------------------------------------------
| config.php contains:
|    $WAF_MODE = 'OFF' / 'DETECT' / 'BLOCK';
| This lets admin.php toggle the WAF.
*/

require_once __DIR__ . '/config.php';
define('WAF_MODE', $WAF_MODE);


/*
|--------------------------------------------------------------------------
| Constants & Bootstrapping
|--------------------------------------------------------------------------
*/

define('WAF_LOG_DIR', __DIR__ . '/waf_logs');
define('WAF_LOG_FILE', WAF_LOG_DIR . '/waf.log');

// create log folder if needed
if (!is_dir(WAF_LOG_DIR)) {
    @mkdir(WAF_LOG_DIR, 0777, true);
}

// Start session early (needed for access control / IDOR)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle the request now
waf_handle_request();



/*
|--------------------------------------------------------------------------
| Core Handler
|--------------------------------------------------------------------------
*/

function waf_handle_request()
{
    if (WAF_MODE === 'OFF') {
        return; // WAF fully disabled
    }

    $path   = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $params = waf_collect_params();

    // 1. SQL Injection
    waf_rule_sqli($params);

    // 2. XSS
    waf_rule_xss($params);

    // 3. Broken Access Control
    waf_rule_access_control($path);

    // 4. File upload checks
    waf_rule_upload_extension();
    waf_rule_block_exec_in_uploads($path);

    // 5. RCE
    waf_rule_rce_cmd($params);

    // 6. IDOR
    waf_rule_idor_profile($path);

    // 7. Sensitive data exposure
    waf_rule_sensitive_get($path, $method);
}



/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function waf_collect_params(): array
{
    $flat = [];

    foreach (['GET' => $_GET, 'POST' => $_POST, 'COOKIE' => $_COOKIE] as $srcName => $src) {
        foreach ($src as $k => $v) {
            if (is_array($v)) {
                $v = implode(' ', waf_flatten_array($v));
            }
            $flat["$srcName.$k"] = (string)$v;
        }
    }

    return $flat;
}

function waf_flatten_array(array $arr): array
{
    $output = [];
    array_walk_recursive($arr, fn($v) => $output[] = $v);
    return $output;
}

function waf_log(string $level, int $ruleId, string $message, array $context = []): void
{
    $entry = [
        'time'    => date('c'),
        'ip'      => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'method'  => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
        'uri'     => $_SERVER['REQUEST_URI'] ?? '',
        'rule_id' => $ruleId,
        'level'   => $level,
        'message' => $message,
        'context' => $context
    ];

    file_put_contents(
        WAF_LOG_FILE,
        json_encode($entry, JSON_UNESCAPED_SLASHES) . PHP_EOL,
        FILE_APPEND
    );
}

function waf_block(int $ruleId, string $message, array $context = []): void
{
    waf_log('BLOCK', $ruleId, $message, $context);

    if (WAF_MODE === 'DETECT') {
        return; // log only
    }

    if (!headers_sent()) {
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: text/html; charset=utf-8');
    }

    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Request Blocked</title>
        <style>
            body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                background: #f3f4f6;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
            }
            .waf-container {
                background: #ffffff;
                border-radius: 14px;
                box-shadow: 0 12px 30px rgba(0, 0, 0, 0.10);
                max-width: 700px;         /* increased width */
                width: 90%;               /* responsive */
                padding: 45px 50px;       /* increased padding */
                box-sizing: border-box;
                text-align: center;
            }
            .waf-badge {
                display: inline-block;
                padding: 6px 14px;
                font-size: 13px;
                letter-spacing: .08em;
                text-transform: uppercase;
                border-radius: 999px;
                background: #fee2e2;
                color: #b91c1c;
                margin-bottom: 16px;
            }
            .waf-title {
                font-size: 30px;          /* larger title */
                margin: 0 0 12px;
                color: #111827;
                font-weight: 700;
            }
            .waf-subtitle {
                font-size: 16px;          /* larger subtitle */
                margin: 0 0 22px;
                color: #4b5563;
            }
            .waf-details {
                font-size: 15px;
                background: #f9fafb;
                border-radius: 10px;
                padding: 16px 18px;
                color: #6b7280;
                text-align: left;
                margin: 0 auto 26px;
                max-width: 100%;
                word-break: break-word;
            }
            .waf-details code {
                font-family: Consolas, Menlo, monospace;
                font-size: 14px;
            }
            .waf-footer {
                font-size: 14px;
                color: #585858ff;
                margin-top: 10px;
            }
            .waf-btn {
                display: inline-block;
                margin-top: 12px;
                padding: 10px 20px;
                border-radius: 6px;
                border: none;
                background: #111827;
                color: #f9fafb;
                font-size: 14px;
                cursor: pointer;
                text-decoration: none;
            }
            .waf-btn:hover {
                background: #0a0d14;
            }
        </style>
    </head>
    <body>
        <div class="waf-container">
            <div class="waf-badge">Request Blocked by WAF</div>
            <h1 class="waf-title">403 · Access Denied</h1>
            <p class="waf-subtitle">
                This request has been blocked for security reasons.
            </p>

            <div class="waf-details">
                <div><strong>Rule ID:</strong> <code><?php echo htmlspecialchars((string)$ruleId); ?></code></div>
                <div><strong>Reason:</strong> <?php echo htmlspecialchars($message); ?></div>
                <div><strong>Path:</strong>
                    <code><?php echo htmlspecialchars($_SERVER['REQUEST_URI'] ?? '/'); ?></code>
                </div>
            </div>

            <div class="waf-footer">
                If this appears to be a mistake, submit a <a href="index.php">report</a>. <br>
                <button class="waf-btn" onclick="history.back()">Go Back</button>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}




/*
|--------------------------------------------------------------------------
| Rules
|--------------------------------------------------------------------------
*/

/* Rule 1001 — SQL Injection */
function waf_rule_sqli(array $params): void
{
    $ruleId = 1001;
    $patterns = [
        "/'(?:\s*or\s*\d+=\d+|\s*and\s*\d+=\d+)/i", // ' OR 1=1
        "/\bunion\b\s+select\b/i",
        "/(--|#)$/m",
        "/;\s*(select|insert|update|delete|drop)\b/i"
    ];

    foreach ($params as $k => $v) {
        foreach ($patterns as $regex) {
            if (preg_match($regex, $v)) {
                waf_block($ruleId, 'SQL Injection attempt detected', [
                    'param' => $k,
                    'value' => $v
                ]);
            }
        }
    }
}


/* Rule 1002 — XSS */
function waf_rule_xss(array $params): void
{
    $ruleId = 1002;
    $patterns = [
        '/<\s*script\b/i',
        '/on\w+\s*=/i',
        '/javascript:/i',
        '/<img[^>]+src=["\']javascript:/i'
    ];

    foreach ($params as $k => $v) {
        foreach ($patterns as $regex) {
            if (preg_match($regex, $v)) {
                waf_block($ruleId, 'XSS attempt detected', [
                    'param' => $k,
                    'value' => $v
                ]);
            }
        }
    }
}


function waf_rule_access_control(string $path): void
{
    $ruleId = 1003;

    // Normalize path
    $path = strtolower($path);

    // Who is logged in?
    $username = $_SESSION['username'] ?? null;
    $loggedIn = !empty($username) || !empty($_SESSION['user_id']);

    // 0) User-specific dashboards: only the matching user can access
    $userDashboards = [
        '/john.php'    => 'john',
        '/michael.php' => 'michael',
    ];

    foreach ($userDashboards as $dashboardPath => $owner) {
        if (strpos($path, $dashboardPath) === 0) {
            if (!$loggedIn || strtolower((string)$username) !== $owner) {
                waf_block($ruleId, 'User dashboard accessed by wrong or unauthenticated user', [
                    'path'     => $path,
                    'username' => $username,
                    'required' => $owner,
                ]);
            }
            return; // don't fall through to other checks
        }
    }

    // 1) Admin-only areas
    $adminOnly = ['/users.php', '/admin.php'];

    foreach ($adminOnly as $p) {
        if (strpos($path, $p) === 0) {
            if (strtolower((string)$username) !== 'admin') {
                waf_block($ruleId, 'Admin-only area accessed by non-admin user', [
                    'path'     => $path,
                    'username' => $username,
                ]);
            }
            return; // don't double-check below
        }
    }

    // 2) Authenticated-only areas (any logged-in user allowed)
    $authOnly = ['/profile.php', '/uploads'];

    foreach ($authOnly as $p) {
        if (strpos($path, $p) === 0) {
            if (!$loggedIn) {
                waf_block($ruleId, 'Protected resource accessed without authentication', [
                    'path' => $path,
                ]);
            }
            return;
        }
    }

    // everything else: no access-control from WAF
}



function waf_rule_upload_extension(): void
{
    $ruleId = 1004;

    if (empty($_FILES) || ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return;
    }

    // Only allow these (for logging purposes)
    $allowedExts = ['jpg', 'jpeg', 'png'];

    foreach ($_FILES as $field => $info) {
        $names = $info['name'] ?? null;
        if ($names === null) {
            continue;
        }

        $names = is_array($names) ? $names : [$names];

        foreach ($names as $name) {
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

            if (!in_array($ext, $allowedExts, true)) {
                waf_log('BLOCK', $ruleId, 'Blocked non-image file upload (by extension)', [
                    'field'    => $field,
                    'filename' => $name,
                    'ext'      => $ext,
                ]);
                // no waf_block() here – let upload.php decide behavior
                return;
            }
        }
    }
}





/* Rule 1005 — Block executing PHP inside uploads/ */
function waf_rule_block_exec_in_uploads($path): void
{
    $ruleId = 1005;

    if (preg_match('#^/uploads/.*\.php$#i', $path)) {
        waf_block($ruleId, 'Blocked execution of PHP inside uploads', [
            'path' => $path
        ]);
    }
}


/* Rule 1006 — RCE via ?cmd= */
function waf_rule_rce_cmd(array $params): void
{
    $ruleId = 1006;

    foreach ($params as $k => $v) {
        if (stripos($k, 'cmd') !== false) {

            if (preg_match('/[;&`|]/', $v) ||
                preg_match('/\b(whoami|id|cat|ls|dir)\b/i', $v)) {

                waf_block($ruleId, 'Command injection attempt', [
                    'param' => $k,
                    'value' => $v
                ]);
            }
        }
    }
}


/* Rule 1007 — IDOR: profile.php?id= */
function waf_rule_idor_profile(string $path): void
{
    $ruleId = 1007;

    if ($path !== '/profile.php') {
        return;
    }

    if (!isset($_GET['id']) || !isset($_SESSION['user_id'])) {
        return;
    }

    if ((int)$_GET['id'] !== (int)$_SESSION['user_id']) {
        waf_block($ruleId, 'IDOR blocked on profile.php', [
            'requested_id' => $_GET['id'],
            'session_id'   => $_SESSION['user_id']
        ]);
    }
}


/* Rule 1008 — Sensitive data in GET (login.php?username=...) */
function waf_rule_sensitive_get(string $path, string $method): void
{
    $ruleId = 1008;

    if ($method !== 'GET') return;
    if ($path !== '/login.php') return;

    if (isset($_GET['username']) || isset($_GET['password'])) {
        waf_block($ruleId, 'Login credentials leaked in GET', [
            'username_present' => isset($_GET['username']),
            'password_present' => isset($_GET['password'])
        ]);
    }
}
